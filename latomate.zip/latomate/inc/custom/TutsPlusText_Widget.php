<?php

/**
 * Created by IntelliJ IDEA.
 * User: oscar
 * Date: 18.03.16
 * Time: 11:13
 */
class TutsPlusText_Widget extends WP_Widget
{
    // widget constructor
    public function __construct(){

    }

    public function widget( $args, $instance ) {
        // outputs the content of the widget
    }

    public function form( $instance ) {
        // creates the back-end form
    }

    // Updating widget replacing old instances with new
    public function update( $new_instance, $old_instance ) {
        // processes widget options on save
    }
}