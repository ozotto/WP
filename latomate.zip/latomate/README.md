LaTomate Theme
===

Theme to website [latomate.ch](http://www.la-tomate.ch/)

Getting Started
---------------

* Download theme
* From Dashboard wordpress, go to Appearance > Themes > Add new
* Upload theme 
* and enjoy

Good luck!
